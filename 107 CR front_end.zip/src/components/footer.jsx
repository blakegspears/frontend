import "./footer.css";

function Footer() {
    return (
        <div className="footer">
            <div className="name">Blake Spears</div>
            <div className="year">2022</div>
            
            </div>
    )
}

export default Footer;